import csv
import datetime

from tkinter import *
from tkinter.messagebox import showinfo

from twitter import *

access_token = "1056837377421991936-CJoiHIsjrVCgi1qh0jaFkXw0gXA5fN"
access_token_secret = "EeWa9B5KYFVcSPTCuWqUox7qTnD5aJABBuAZE2wlqmKAw"
consumer_key = "uPlOcYQQWFxS6l63SUmt5dRNP"
consumer_secret = "ELgc6p8a8nIQPrvl5ToMyULJDqFkqnQ32U2sWtmGQQJn68n09R"

t = Twitter(auth=OAuth(access_token, access_token_secret, consumer_key, consumer_secret))


with open("Twitter.csv", "a", newline="") as myCSVFile:
    write = csv.writer(myCSVFile, delimiter=":")


    class App(Frame):

        def __init__(self, master=None):
            Frame.__init__(self, master)
            self.grid()
            self.output()

# Dit is de interface die de klant zou zien
        def output(self):

            self.showLogo = Entry(root)
            Label(text="Welkom bij de recentie interface van de NS\n", background='yellow', foreground='blue',
                  font=('Frutiger', 40)).grid(row=1)
            self.titel = Entry(root)
            Label(text="Voor de reiziger\n", background='yellow', foreground='blue', font=('Frutiger', 30)).grid(row=2)
            self.ondertitel = Entry(root)
            Label(text="Vul onderstaand uw naam in:", background='yellow', foreground='blue',
                  font=('Frutiger', 20)).grid(row=3)
            self.naam = Entry(root)
            self.naam.grid(row=4)
            Label(text="Vul hier uw recensie in(maximaal 140 karakters):", background='yellow', foreground='blue',
                  font=('Frutiger', 20)).grid(row=5)
            self.recensie = Entry(root, width=100)
            self.recensie.grid(row=6),
            self.button = Button(root, text="Submit", foreground='blue', font=('Frutiger', 15,),
                                 command=self.writetofile)
            self.button.grid(row=7)

# Hiermee schrijft die de tweet naar een csv-bestand zo niet komt er een bericht waarin wordt gezegd dat de tweet korter dan 140 karakters moet zijn
        def writetofile(self):

            if len(self.recensie.get()) <= 140:
                write.writerow(["Om",datetime.datetime.now().strftime("%d-%m-%y %H:%M"), "schreef",self.naam.get(), self.recensie.get()])
                berichtsubmit = ("Uw bericht is verstuurd naar de NS!\n"
                                     "Eerst wordt het bericht gecontroleerd door de NS\n",)
                showinfo(title='Submitted', message=berichtsubmit)
            else:
                berichtsubmit = ("Het bericht moet korter zijn dan 140 karakters probeer opnieuw")
                showinfo(title='Submitted', message=berichtsubmit)
                self.close = Button(self.master, text="Close", command=self.master.destroy)


    if __name__=="__main__":
        root = Tk()
        root.configure(background="yellow")
        root.title("Twitter NS recentie reiziger")
        root.geometry("1000x400")
        app=App(master=root)
        app.mainloop()
        root.mainloop()

# Als de medewerker van NS op accept drukt dan wordt de tweet op twitter gezet en uit het csv-bestand verwijderd
def acceptMelding():
    berichtAccept = ("Het bericht is op Twitter geplaatst!\n"
               "NS kan dit dit bericht nu verder behandelen\n")
    showinfo(title='Accept', message=berichtAccept)
    file_reader = open('Twitter.csv', "rt", encoding='ascii')
    read = csv.reader(file_reader)
    for row in read:
        print(', '.join(row))
    t.statuses.update(status=(', '.join(row)))
    close = open("Twitter.csv", "w+")
    close.close()


# Als de medewerker van NS op Reject drukt wordt de tweet uit het CSV bestand gehaald en in een nieuw CSV-bestand gezet
def rejectMelding():
    bericht = ("Het bericht wordt niet op Twitter geplaatst\n" 
              "Het bericht is opgeslagen in het log.bestand\n")

    showinfo(title='Reject', message=bericht)
    with open(r"rejectTwitter.csv", "w") as myCSVFile:
        writes = csv.writer(myCSVFile)
        with open(r"Twitter.csv", "r") as infile:
            filereader = csv.reader(infile)
            for row in filereader:
                writes.writerow(row)
    close = open("Twitter.csv", "w+")
    close.close()



# Hiermee kan de NS medewerker de tweet zijn die hij/zij moet gaan accepten of rejecten
def inlezen():
    with open("Twitter.csv", newline="") as file:
        reader = csv.reader(file)

        r = 0
        for col in reader:
            c = 0
            for row in col:
                label10 = Label(root, width=100, height=2,
                        text=row, relief=RIDGE)
                label10.pack()
                c += 1
            r += 1

    root.mainloop()

# Dit is de interface voor de NS medewerker
root = Tk()


label = Label(master=root, text='Welkom bij de NS-Consumentenzuil', font=('Times New Roman', 40, ))
label2 = Label(master=root, text='Onderstaand kunt u de recentie goedkeuren', font=('Times New Roman', 20))
label3 = Label(master=root, text="met 'Accept'",  font=('Times New Roman', 15,))
label4 = Label(master=root, text='Of foutkeuren', font=('Times New Roman', 20))
label5 = Label(master=root, text="'Reject'", font=('Times New Roman', 15))


label.pack()
label2.pack()
label3.pack()
label4.pack()
label5.pack()


button = Button(master=root, text='Accept', font=('Helvetica', 30,), command=acceptMelding)
button.pack(side = LEFT, pady=10)

button2 = Button(master=root, text="Reject", font=('Helvetica', 30,),  command=rejectMelding)
button2.pack(side = RIGHT, pady=10)

button3 = Button(master=root, text="Bericht inlezen", font=('Helvetica', 30,), command=inlezen)
button3.pack(side = BOTTOM, pady=10)
root.title("Twitter NS recentie NS medewerker")
root.mainloop()
